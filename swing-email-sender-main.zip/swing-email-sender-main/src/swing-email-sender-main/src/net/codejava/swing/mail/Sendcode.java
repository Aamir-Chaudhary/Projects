package employee.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.Random;

public class Sendcode extends JFrame {
    private int randomCode;
    private JTextField txtEmail;
    private JTextField txtCode;

    public Sendcode() {
        initComponents();
        setResizable(false);
    }

    private void initComponents() {
        // Component initialization code omitted for brevity

        btnSend.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnSendActionPerformed(evt);
            }
        });

        btnVerify.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnVerifyActionPerformed(evt);
            }
        });
    }

    private void btnSendActionPerformed(ActionEvent evt) {
        JOptionPane.showMessageDialog(null, "Wait it may take a few seconds....");

        try {
            Random rand = new Random();
            randomCode = rand.nextInt(999999);

            String to = txtEmail.getText();
            String subject = "Resetting Code";
            String message = "Your reset code is " + randomCode;

            // Send email using EmailUtility
            Sendcode.sendEmail(to, subject, message);

            JOptionPane.showMessageDialog(null, "Code has been sent to the email");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to send email: " + e.getMessage());
        }
    }

    private void btnVerifyActionPerformed(ActionEvent evt) {
        try {
            int enteredCode = Integer.parseInt(txtCode.getText());
            if (enteredCode == randomCode) {
                Reset rs = new Reset(txtEmail.getText());
                rs.setVisible(true);
                setVisible(false);
            } else {
                JOptionPane.showMessageDialog(null, "Code does not match");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid code. Please enter a valid number.");
        }
    }
}
