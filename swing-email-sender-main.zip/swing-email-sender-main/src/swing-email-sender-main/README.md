# swing-email-sender
Sample Project for Java Swing E-mail Sender program
### Follow our written tutorial here: [Java Swing application for sending e-mail (with attachments)](https://www.codejava.net/coding/swing-application-for-sending-e-mail-with-attachments)
